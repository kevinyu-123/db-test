create
    definer = root@localhost procedure GetEmployeeById(IN emp_id int)
BEGIN
    SELECT *
    FROM UserEntity
    WHERE id = emp_id;
END;

