create
    definer = root@localhost procedure GetEmployeeById(IN user_id int)
BEGIN
    SELECT *
    FROM UserEntity
    WHERE id = user_id;
END;

