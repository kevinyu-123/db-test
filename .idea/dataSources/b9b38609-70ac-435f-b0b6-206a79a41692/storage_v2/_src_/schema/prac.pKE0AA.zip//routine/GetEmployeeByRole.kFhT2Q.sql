create
    definer = root@localhost procedure GetEmployeeByRole(IN user_role varchar(40))
BEGIN
    SELECT *
    FROM UserEntity
    WHERE role = user_role;
END;

