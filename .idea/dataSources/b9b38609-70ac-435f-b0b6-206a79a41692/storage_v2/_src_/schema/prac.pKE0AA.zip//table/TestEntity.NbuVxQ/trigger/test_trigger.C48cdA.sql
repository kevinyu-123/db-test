create definer = root@localhost trigger test_trigger
    after insert
    on TestEntity
    for each row
begin
    INSERT INTO UserEntity (password, role, username )
    VALUES (5555, 'trigger', 'trigger');
end;

