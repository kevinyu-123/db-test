create definer = root@localhost trigger test_trigger
    after insert
    on TestEntity
    for each row
begin
    INSERT INTO UserEntity (role, username )
    VALUES ( 'trigger', 'trigger');
end;

